#ifndef LM35_H
#define LM35_H
#include "Arduino.h"

class LM35{
public:
    LM35(int pin);
    void getTempstr(float value, float miliv, int temp);
private:
    int _pin;
    float _value;
    float _miliv;
    int _temp;
};

#endif // LM35_H
