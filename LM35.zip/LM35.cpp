#include "LM35.h"
#include "Arduino.h"

LM35::LM35(int pin)
{
    pinMode(pin, INPUT);
    _pin = pin;
}
float LM35::getTemp()
{
    float value = analogRead(_pin);
    float milivolt = (float(value) * 5000) / 1024;
    float temp = float(milivolt) / 10;
    return temp;
}
