#define "LM35.h"
#include "Arduino.h"

LM35::LM35(int pin){
    pinmode(pin, OUTPUT);
    _pin = pin;
}
void LM35::getTempstr(float value, float miliv, int temp){
    value = analogRead(_pin);
    miliv = (value * 5000) / 1024;
    temp = miliv / 10;
    _value = value;
    _miliv = miliv;
    _temp = temp;
} 
